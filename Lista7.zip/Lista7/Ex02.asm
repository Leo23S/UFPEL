.text
	li $sp, 0x10010004
	
	addi $t0, $0, 150
	addi $t1, $0, 230
	addi $t2, $0, 991
	addi $t3, $0, 0
	
	jal soma3n
	
soma:	addi $t4, $a0, $a1
	jr $ra
	
	
soma3n:	addiu $sp, $sp, -4
	sw $r4, ($sp)

	jal soma
	jr $ra