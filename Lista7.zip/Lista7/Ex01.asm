.text
	addi $v0, $0, 5
	syscall
	add $a0, $0, $v0
	
	addi $v0, $0, 5
	syscall
	add $a1, $0, $v0
	
	addi $v0, $0, 5
	syscall
	add $a2, $0, $v0
	
	add $t5, $a0, $a1
	add $t5, $t5, $a2
	jal media
	add $a0, $0, $t5
	addi $v0, $0, 1
	syscall
	
	addi $v0, $0, 10
	syscall
	
	
media:	addi $t0, $0, 3
	div $t5, $t0
	mflo $t5
	
	jr $ra